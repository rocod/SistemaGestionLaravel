

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Redes Sociales</h1>
                    </div>

                    <div class="row">

                        <table class="table table-striped">
                          <thead>
                            <tr>
                              <th scope="col">Red Social</th>
                              <th scope="col">Dirección</th>
                              
                              <th scope="col">
                                Modificar
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $redes_sociales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red_social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($red_social->nombre); ?></td>
                              <td><?php echo e($red_social->direccion); ?></td>
                              <td>
                                <a title="Editar" class="text-info" href="<?php echo e(route('editarRedSocialForm', $red_social)); ?>">
                                    <i class="fas fa-pencil-alt fa-2x"></i>
                                </a>
                              </td>
                              
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                          </tbody>
                        </table>
                     
                    </div>

                   
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.interior', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sanjavuchoLaravel\resources\views/seccionesWeb/redesSociales/index.blade.php ENDPATH**/ ?>