

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Operadores</h1>

                    </div>
                    <div class="row">
                        <div class="col">
                            <h3 class="text-primary">Agregar nuevo</h3>
                        </div>
                        
                    </div>

                    <div class="row">

                        <div class="col-md-12 ">
                           <form method="post" action="<?php echo e(route('grabarOperador')); ?>">
                            <?php echo csrf_field(); ?>                           
                                <div class="form-group">
                                    <label for="name" class="form-label">Nombre</label>
                                    <input type="text" name="name" class="form-control" id="name" aria-describedby="Nombre"  placeholder="Nombre" required value="" />
                                </div>
                                <div class="form-group">
                                    <label for="apellido" class="form-label">Apellido</label>
                                    <input type="text" name="apellido" class="form-control" id="apellido" aria-describedby="Apellido"  placeholder="Apellido" required value="" />
                                </div>
                                <div class="form-group">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" id="email" aria-describedby="Email"  placeholder="Email" required value="" />
                                </div>
                                <div class="form-group">
                                    <label for="password" class="form-label"><?php echo e(__('Contraseña')); ?></label>

                                    
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div>
                                <div class="form-group ">
                                    <label for="facturas_dias" class="form-label">Cantidad de días para muestreo de facturas</label> <small id="emailHelp" class="form-text text-muted">(En caso de no querer limitar los días dejar en 0)    </small>                                                     
                                    <input type="text" aria-describedby="Cantidad de días para muestreo de facturas"  class="form-control" name="facturas_dias" id="facturas_dias" value="0" >
                                </div>
                                <div class="form-group">
                                    <label for="solo_sus_fact" class="form-label">Ve solo sus facturas?</label>                   
                                    <select class="form-control" name="solo_sus_fact">
                                        <option value="1">Si</option>
                                        <option selected value="0">No</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col secNombre">
                                            <div><?php echo e($seccion->nombre); ?></div>
                                            <ul class="list-unstyled">
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($rol->seccion == $seccion->id): ?>
                                                <li><input  type="checkbox" name="rol<?php echo e($rol->id); ?>" /> <?php echo e($rol->nombre); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <ul>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>    
                                <button type="submit" class="btn btn-primary" title="grabar">Agregar
                                </button>
                               
                            </form>
                        </div>
                    </div>                   
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.interior', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sanjavuchoLaravel\resources\views/usuarios/operadores/agregarForm.blade.php ENDPATH**/ ?>