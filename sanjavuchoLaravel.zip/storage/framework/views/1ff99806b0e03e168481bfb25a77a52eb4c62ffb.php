

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Opiniones</h1>
                    </div>

                    <div class="row">

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Producto</th>
                                    <th scope="col">Puntaje</th>
                                    <th scope="col">E-mail cliente</th>
                                    <th scope="col">Opinión</th>
                                    <th scope="col">Estado</th>
                                    <th scope="col">Aceptar</th>
                                    <th scope="col">Rechazar</th>
                                    <th scope="col">
                                    <a class="text-success" href="agregarOpinion" title="Agregar nueva forma de pago">
                                        <i class="fas fa-plus-circle fa-2x "></i>
                                    </a>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $opiniones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opinion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($opinion->producto); ?></td>
                                    <td><?php echo e($opinion->puntaje); ?></td>
                                    <td><?php echo e($opinion->user->email); ?></td>
                                    <td><?php echo e($opinion->get_resumen); ?></td>
                                    <td><?php echo e($opinion->estado); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('aceptarOpinion', $opinion)); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button type="submit" class="btn btn-outline-success">Aceptar</button>
                                        </form>
                                    </td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('rechazarOpinion', $opinion)); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button type="submit" class="btn btn-outline-danger">Rechazar</button>
                                        </form>
                                    </td>
                                    <td></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.interior', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sanjavuchoLaravel\resources\views/seccionesWeb/opiniones/index.blade.php ENDPATH**/ ?>