<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Preguntas Frecuentes</h1>
                    </div>

                    <div class="row">

                        <table class="table table-striped">
                          <thead>
                            <tr>
                              <th scope="col">Pregunta</th>
                              <th scope="col">Respuesta</th>
                              <th scope="col">Posición</th>
                              <th scope="col"></th>
                              <th scope="col">
                                <a class="text-success" href="/agregar_pregunta" title="Agregar nueva pregunta">
                                    <i class="fas fa-plus-circle fa-2x "></i>
                                </a>
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($pregunta->pregunta); ?></td>
                              <td><?php echo e($pregunta->respuesta); ?></td>
                              <td><?php echo e($pregunta->posicion); ?></td>
                              <td>
                                <a title="Editar" class="text-info" href="<?php echo e(route('editarPreguntaForm', ['id'=>$pregunta->id])); ?>">
                                    <i class="fas fa-pencil-alt fa-2x"></i>
                                </a>
                               </td>
                              <td>
                               <a title="Eliminar" class="text-info" href="<?php echo e(route('eliminarPreguntaForm', ['id'=>$pregunta->id])); ?>">
                                   <i class="far fa-trash-alt fa-2x"></i>
                                </a>
                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                          </tbody>
                        </table>
                     
                    </div>

                   
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.interior', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sanjavuchoLaravel\resources\views/seccionesWeb/preguntasFrecuentes/lista.blade.php ENDPATH**/ ?>