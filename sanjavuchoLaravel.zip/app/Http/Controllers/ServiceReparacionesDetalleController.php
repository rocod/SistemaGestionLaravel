<?php

namespace App\Http\Controllers;

use App\Models\ServiceReparacionesDetalle;
use Illuminate\Http\Request;

class ServiceReparacionesDetalleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ServiceReparacionesDetalle  $serviceReparacionesDetalle
     * @return \Illuminate\Http\Response
     */
    public function show(ServiceReparacionesDetalle $serviceReparacionesDetalle)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ServiceReparacionesDetalle  $serviceReparacionesDetalle
     * @return \Illuminate\Http\Response
     */
    public function edit(ServiceReparacionesDetalle $serviceReparacionesDetalle)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ServiceReparacionesDetalle  $serviceReparacionesDetalle
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ServiceReparacionesDetalle $serviceReparacionesDetalle)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ServiceReparacionesDetalle  $serviceReparacionesDetalle
     * @return \Illuminate\Http\Response
     */
    public function destroy(ServiceReparacionesDetalle $serviceReparacionesDetalle)
    {
        //
    }
}
