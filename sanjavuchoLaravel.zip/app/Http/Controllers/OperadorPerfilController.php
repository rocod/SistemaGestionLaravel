<?php

namespace App\Http\Controllers;

use App\Models\OperadorPerfil;
use Illuminate\Http\Request;

class OperadorPerfilController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\OperadorPerfil  $operadorPerfil
     * @return \Illuminate\Http\Response
     */
    public function show(OperadorPerfil $operadorPerfil)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\OperadorPerfil  $operadorPerfil
     * @return \Illuminate\Http\Response
     */
    public function edit(OperadorPerfil $operadorPerfil)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\OperadorPerfil  $operadorPerfil
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, OperadorPerfil $operadorPerfil)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\OperadorPerfil  $operadorPerfil
     * @return \Illuminate\Http\Response
     */
    public function destroy(OperadorPerfil $operadorPerfil)
    {
        //
    }
}
