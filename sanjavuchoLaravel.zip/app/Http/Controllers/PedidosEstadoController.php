<?php

namespace App\Http\Controllers;

use App\Models\PedidosEstado;
use Illuminate\Http\Request;

class PedidosEstadoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PedidosEstado  $pedidosEstado
     * @return \Illuminate\Http\Response
     */
    public function show(PedidosEstado $pedidosEstado)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PedidosEstado  $pedidosEstado
     * @return \Illuminate\Http\Response
     */
    public function edit(PedidosEstado $pedidosEstado)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PedidosEstado  $pedidosEstado
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PedidosEstado $pedidosEstado)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PedidosEstado  $pedidosEstado
     * @return \Illuminate\Http\Response
     */
    public function destroy(PedidosEstado $pedidosEstado)
    {
        //
    }
}
