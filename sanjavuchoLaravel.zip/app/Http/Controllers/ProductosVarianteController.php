<?php

namespace App\Http\Controllers;

use App\Models\ProductosVariante;
use Illuminate\Http\Request;

class ProductosVarianteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ProductosVariante  $productosVariante
     * @return \Illuminate\Http\Response
     */
    public function show(ProductosVariante $productosVariante)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ProductosVariante  $productosVariante
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductosVariante $productosVariante)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ProductosVariante  $productosVariante
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductosVariante $productosVariante)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ProductosVariante  $productosVariante
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductosVariante $productosVariante)
    {
        //
    }
}
