<?php

namespace App\Http\Controllers;

use App\Models\Logueo;
use Illuminate\Http\Request;

class LogueoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Logueo  $logueo
     * @return \Illuminate\Http\Response
     */
    public function show(Logueo $logueo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Logueo  $logueo
     * @return \Illuminate\Http\Response
     */
    public function edit(Logueo $logueo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Logueo  $logueo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Logueo $logueo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Logueo  $logueo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Logueo $logueo)
    {
        //
    }
}
