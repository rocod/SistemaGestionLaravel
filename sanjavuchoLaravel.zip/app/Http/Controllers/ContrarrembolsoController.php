<?php

namespace App\Http\Controllers;

use App\Models\contrarrembolso;
use Illuminate\Http\Request;

class ContrarrembolsoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\contrarrembolso  $contrarrembolso
     * @return \Illuminate\Http\Response
     */
    public function show(contrarrembolso $contrarrembolso)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\contrarrembolso  $contrarrembolso
     * @return \Illuminate\Http\Response
     */
    public function edit(contrarrembolso $contrarrembolso)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\contrarrembolso  $contrarrembolso
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, contrarrembolso $contrarrembolso)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\contrarrembolso  $contrarrembolso
     * @return \Illuminate\Http\Response
     */
    public function destroy(contrarrembolso $contrarrembolso)
    {
        //
    }
}
