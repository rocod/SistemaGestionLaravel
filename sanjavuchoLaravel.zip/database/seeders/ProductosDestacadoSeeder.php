<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ProductosDestacadoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
