<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class FormaEnvioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
