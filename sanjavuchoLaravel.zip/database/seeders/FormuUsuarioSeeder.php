<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class FormuUsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
