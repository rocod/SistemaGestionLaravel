<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DolarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
