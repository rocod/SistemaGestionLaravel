<?php

namespace Database\Factories;

use App\Models\RedesSociales;
use Illuminate\Database\Eloquent\Factories\Factory;

class RedesSocialesFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = RedesSociales::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'nombre' => $this->faker->name(),
            'direccion' => $this->faker->url()
        ];
    }
}
