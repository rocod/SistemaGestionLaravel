<?php

namespace Database\Factories;

use App\Models\Dolar;
use Illuminate\Database\Eloquent\Factories\Factory;

class DolarFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Dolar::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
