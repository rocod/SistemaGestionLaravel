<?php

namespace Database\Factories;

use App\Models\FormuUsuario;
use Illuminate\Database\Eloquent\Factories\Factory;

class FormuUsuarioFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = FormuUsuario::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
