<?php

namespace Database\Factories;

use App\Models\producto_estado;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductoEstadoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = producto_estado::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
