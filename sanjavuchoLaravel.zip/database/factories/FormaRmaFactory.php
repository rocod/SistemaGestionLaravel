<?php

namespace Database\Factories;

use App\Models\FormaRma;
use Illuminate\Database\Eloquent\Factories\Factory;

class FormaRmaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = FormaRma::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
