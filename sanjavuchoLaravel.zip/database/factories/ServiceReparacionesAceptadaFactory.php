<?php

namespace Database\Factories;

use App\Models\ServiceReparacionesAceptada;
use Illuminate\Database\Eloquent\Factories\Factory;

class ServiceReparacionesAceptadaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ServiceReparacionesAceptada::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
