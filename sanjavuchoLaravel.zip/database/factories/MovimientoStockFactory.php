<?php

namespace Database\Factories;

use App\Models\MovimientoStock;
use Illuminate\Database\Eloquent\Factories\Factory;

class MovimientoStockFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = MovimientoStock::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
