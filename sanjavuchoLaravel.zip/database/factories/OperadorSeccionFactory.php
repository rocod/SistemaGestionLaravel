<?php

namespace Database\Factories;

use App\Models\OperadorSeccion;
use Illuminate\Database\Eloquent\Factories\Factory;

class OperadorSeccionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = OperadorSeccion::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
