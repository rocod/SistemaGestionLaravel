<?php

namespace Database\Factories;

use App\Models\TerminalRetiro;
use Illuminate\Database\Eloquent\Factories\Factory;

class TerminalRetiroFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TerminalRetiro::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
